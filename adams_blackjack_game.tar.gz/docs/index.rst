.. blackjack documentation master file, created by
   sphinx-quickstart on Wed Sep 26 10:48:44 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
.. https://pythonhosted.org/an_example_pypi_project/sphinx.html

Welcome to Adam's Blackjack documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   install
   run
   tests
   code

Indices and tables
==================

* :ref:`search`
