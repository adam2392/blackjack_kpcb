Running The Blackjack Module
=====================================

Running it is as simple as running any python script. ::

    python3 app.py