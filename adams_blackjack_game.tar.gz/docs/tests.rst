Tests
========

Here, I describe how I deployed my tests and performed unit testing on the entire blackjack game backend functions.

Within the directory of the blackjack_kpcb app, you can run::

    pytest ./

