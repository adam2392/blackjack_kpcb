Install
=========

This is where you write how to get a new laptop to run this project.

If you are running python3 ::

    python3 -m venv .venv
    pip install -r requirements.txt
    python3 app.py


Useful Commands:

1. h: hit for a new card

2. s: stand on a hand

3. d: double a hand (optional)

4. p: split a hand (optional and only possible if you start with two of the same cards, such as 4,4, or A,A, or J,J)


